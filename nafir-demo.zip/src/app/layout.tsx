import type { Metadata } from "next";
import { Geist, Geist_Mono } from "next/font/google";
import "./globals.css";

// 👇 استيراد موفّر اللغة وزر التبديل
import { I18nProvider } from "@/contexts/I18nProvider";
import LanguageToggle from "@/components/LanguageToggle";

const geistSans = Geist({
  variable: "--font-geist-sans",
  subsets: ["latin"],
});

const geistMono = Geist_Mono({
  variable: "--font-geist-mono",
  subsets: ["latin"],
});

export const metadata: Metadata = {
  title: "NAFIR",
  description: "تطبيق الاستدعاء NAFIR",
};

export default function RootLayout({
  children,
}: Readonly<{
  children: React.ReactNode;
}>) {
  return (
    <html lang="ar">
      <body
        className={`${geistSans.variable} ${geistMono.variable} antialiased`}
      >
        {/* غلّف المشروع بالـ I18nProvider */}
        <I18nProvider>
          {/* الهيدر */}
          <header className="flex items-center justify-between p-4 border-b">
            <div className="font-bold text-xl">NAFIR</div>
            <LanguageToggle />
          </header>

          {/* باقي الصفحات */}
          {children}
        </I18nProvider>
      </body>
    </html>
  );
}
