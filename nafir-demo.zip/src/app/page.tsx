"use client";

import Link from "next/link";
import { BellRing, Moon, Sun, Phone } from "lucide-react";
import React from "react";
// ⬇️ استيراد قائمة الموظفين (عدّل المسار إذا ما عندك alias @)
import EmployeeList from "@/components/EmployeeList";

export default function Landing() {
  const [dark, setDark] = React.useState(false);

  React.useEffect(() => {
    const saved = localStorage.getItem("nafir_dark") === "1";
    setDark(saved);
    document.documentElement.classList.toggle("dark", saved);
  }, []);

  const toggleDark = () => {
    const next = !dark;
    setDark(next);
    document.documentElement.classList.toggle("dark", next);
    localStorage.setItem("nafir_dark", next ? "1" : "0");
  };

  const WHATSAPP_NUMBER = "966500000000"; // عدّل الرقم الدولي بدون +
  const message = encodeURIComponent("مرحبًا، أود تجربة نموذج NAFIR.");
  const waLink = `https://wa.me/${WHATSAPP_NUMBER}?text=${message}`;

  return (
    <main
      dir="rtl"
      className="min-h-screen bg-gradient-to-b from-gray-50 to-white dark:from-gray-900 dark:to-gray-950 dark:text-gray-100"
    >
      <header className="max-w-6xl mx-auto px-6 py-6 flex items-center justify-between">
        <div className="flex items-center gap-2">
          <BellRing className="text-red-600" />
          <span className="font-extrabold text-xl">NAFIR</span>
        </div>
        <nav className="flex items-center gap-3 text-sm text-gray-600 dark:text-gray-300">
          <a className="hover:text-gray-900 dark:hover:text-white" href="#features">
            المزايا
          </a>
          <a className="hover:text-gray-900 dark:hover:text-white" href="#how">
            كيف يعمل
          </a>
          <a
            className="px-3 py-2 rounded-xl border hover:bg-gray-50 dark:hover:bg-gray-800 flex items-center gap-2"
            href={waLink}
            target="_blank"
          >
            <Phone className="w-4 h-4" /> واتساب
          </a>
          <button
            onClick={toggleDark}
            className="p-2 rounded-lg border hover:bg-gray-50 dark:hover:bg-gray-800"
            title="الوضع الداكن"
          >
            {dark ? <Sun className="w-4 h-4" /> : <Moon className="w-4 h-4" />}
          </button>
          <Link
            className="px-4 py-2 bg-gray-900 text-white rounded-xl dark:bg-white dark:text-gray-900"
            href="/demo"
          >
            جرب النموذج
          </Link>
        </nav>
      </header>

      {/* البطل */}
      <section className="max-w-6xl mx-auto px-6 py-20 grid lg:grid-cols-2 gap-10 items-center">
        <div>
          <h1 className="text-3xl md:text-5xl font-extrabold leading-tight text-gray-900 dark:text-white">
            نظام NAFIR للاستدعاء العاجل
            <br />
            للقطاعات العسكرية والمدنية
          </h1>
          <p className="mt-4 text-gray-600 dark:text-gray-300">
            أرسل نداءً موحدًا عبر الاتصال والرسائل، وتابع الحالات لحظيًا: في الطريق، تم الرد،
            غير متاح، لم يرد.
          </p>
          <div className="mt-8 flex gap-3">
            <Link
              href="/demo"
              className="px-5 py-3 rounded-xl bg-red-600 text-white font-semibold hover:bg-red-700"
            >
              جرب الديمو
            </Link>
            <a
              href="#features"
              className="px-5 py-3 rounded-xl border font-semibold text-gray-700 hover:bg-gray-50 dark:text-gray-200 dark:hover:bg-gray-800"
            >
              تعرّف أكثر
            </a>
          </div>
        </div>
        <div className="bg-white dark:bg-gray-900 rounded-2xl shadow p-6 border border-black/5 dark:border-white/10">
          <div className="h-56 rounded-xl bg-gradient-to-br from-red-100 to-gray-100 dark:from-gray-800 dark:to-gray-700 grid place-items-center text-gray-600 dark:text-gray-300">
            لقطة توضيحية للوحة المتابعة
          </div>
          <p className="mt-3 text-xs text-gray-500 dark:text-gray-400">النسخة المعروضة للعرض فقط.</p>
        </div>
      </section>

      {/* قسم المزايا (اختياري – فقط للروابط) */}
      <section id="features" className="max-w-6xl mx-auto px-6 py-8">
        <h2 className="text-xl font-bold mb-3">المزايا</h2>
        <ul className="list-disc pr-6 text-gray-700 dark:text-gray-200 space-y-1">
          <li>تعدد اللغات (عربي/إنجليزي) مع تبديل فوري.</li>
          <li>خريطة تفاعلية لعرض مواقع الموظفين ومكان الاستدعاء.</li>
          <li>إظهار المسافة بالكيلومتر بجانب الحالة.</li>
          <li>فرز الأقرب أولًا وتصفية حسب التخصص.</li>
        </ul>
      </section>

      {/* كيف يعمل (للربط فقط) */}
      <section id="how" className="max-w-6xl mx-auto px-6 py-8">
        <h2 className="text-xl font-bold mb-3">كيف يعمل NAFIR</h2>
        <ol className="list-decimal pr-6 text-gray-700 dark:text-gray-200 space-y-1">
          <li>اختر الموظف المناسب.</li>
          <li>اضغط استدعاء.</li>
          <li>يستلم الموظف إشعارًا فوريًا.</li>
          <li>تابع الحالة والمسافة على الخريطة.</li>
        </ol>
      </section>

      {/* قائمة الموظفين + الخريطة */}
      <section className="max-w-6xl mx-auto px-6 py-10">
        <h2 className="text-xl font-bold mb-4">الموظفون الأقرب</h2>
        <EmployeeList />
      </section>

      <footer className="max-w-6xl mx-auto px-6 py-10 text-xs text-gray-500 dark:text-gray-400">
        © {new Date().getFullYear()} NAFIR – نموذج عرض.
      </footer>
    </main>
  );
}
