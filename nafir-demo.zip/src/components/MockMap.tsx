"use client";
import React from "react";

type Point = { lat: number; lng: number; label?: string; color?: string };
type Bounds = { minLat: number; maxLat: number; minLng: number; maxLng: number };

function norm(v: number, vmin: number, vmax: number) {
  return (v - vmin) / Math.max(1e-9, vmax - vmin);
}

export default function MockMap({
  points,
  bounds,
  connectFirstTwo = true,
  title,
}: {
  points: Point[];
  bounds: Bounds;
  connectFirstTwo?: boolean;
  title?: string;
}) {
  const W = 640, H = 320;
  const mapped = points.map((p) => {
    const x = norm(p.lng, bounds.minLng, bounds.maxLng) * W;
    const y = (1 - norm(p.lat, bounds.minLat, bounds.maxLat)) * H;
    return { ...p, x, y };
  });

  const line =
    connectFirstTwo && mapped.length >= 2
      ? { x1: mapped[0].x, y1: mapped[0].y, x2: mapped[1].x, y2: mapped[1].y }
      : null;

  return (
    <div className="w-full overflow-hidden rounded-2xl border bg-white">
      <div className="flex items-center justify-between px-4 py-2 text-sm text-gray-600">
        <div>{title ? `خريطة محاكة – ${title}` : "خريطة محاكة"}</div>
        <div>بدون اشتراك</div>
      </div>
      <svg viewBox={`0 0 ${W} ${H}`} className="block w-full h-64">
        <defs>
          <pattern id="grid" width="40" height="40" patternUnits="userSpaceOnUse">
            <path d="M 40 0 L 0 0 0 40" fill="none" stroke="#e5e7eb" strokeWidth="1" />
          </pattern>
        </defs>
        <rect x="0" y="0" width={W} height={H} fill="url(#grid)" />
        {line && (
          <line x1={line.x1} y1={line.y1} x2={line.x2} y2={line.y2} stroke="#64748b" strokeDasharray="6 6" strokeWidth="2" />
        )}
        {mapped.map((p, i) => (
          <g key={i}>
            <circle cx={p.x} cy={p.y} r="7" fill={p.color || (i === 0 ? "#1d4ed8" : "#10b981")} />
            {p.label && (
              <text x={p.x + 10} y={p.y - 10} fontSize="12" fill="#111827" style={{ userSelect: "none" }}>
                {p.label}
              </text>
            )}
          </g>
        ))}
        <rect x="0" y="0" width={W} height={H} fill="none" stroke="#cbd5e1" />
      </svg>
      <div className="px-4 pb-3 text-xs text-gray-500">عرض تقريبي دون خرائط خارجية.</div>
    </div>
  );
}
